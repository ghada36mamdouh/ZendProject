var mysql = require('mysql');
var url = require('url');

  var con = mysql.createConnection
  ({
      host     : 'localhost',
      user     : 'zahra',
      password : 'iti',
      database : 'lab1_Node'
  });

module.exports=function listData (req,res) {
  var queryParam = url.parse(req.url, true).query;
  //var queryParam=pathname.substr(1)

  console.log(queryParam.id);

	con.query('SELECT * from products where id=?' ,[queryParam.id] ,function(err, rows, fields) {
    if (err) throw err;
		console.log("test from Db");
		res.end(JSON.stringify(rows))
  
		});
      res.end();
};


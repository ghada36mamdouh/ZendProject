$.ajax
({
	url:'/update',
	method:'GET',
	data: {},
	success:
			function(response)
			{
				console.log("test from ajax"+response);
				for (var i = 0; i < response.length; i++)
				{
					var row='<tr><td>'+response[i].name+'</td><td>'+response[i].price+'</td><td>'+response[i].description+'</td><td><a href="/save.html">Save</a></td></tr>';
					$("#data").append(row);
					
				}

			},
	dataType: 'json'		

});
var mysql = require('mysql');
var querystring = require('querystring');

  var con = mysql.createConnection
  ({
      host     : 'localhost',
      user     : 'zahra',
      password : 'iti',
      database : 'lab1_Node'
  });

   
module.exports=function addData (req, res) {
    var body = '';
    req.on("data", function(chunk) {
        body+=chunk;
      });

    req.on("end", function() {
      	console.log(body);
         var Body = querystring.parse(body);
         console.log(Body);
        con.query('INSERT INTO products SET ?', Body, function(err,res){
        });  
        res.end();
 
    });


} ;
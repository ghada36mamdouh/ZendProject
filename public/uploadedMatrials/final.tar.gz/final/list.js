var mysql = require('mysql');

  var con = mysql.createConnection
  ({
      host     : 'localhost',
      user     : 'zahra',
      password : 'iti',
      database : 'lab1_Node'
  });


module.exports= function listData (req,res) {
	con.query('SELECT * from products', function(err, rows, fields) {
    if (err) throw err;
		console.log("test from Db");
		res.end(JSON.stringify(rows))
		});
    
};

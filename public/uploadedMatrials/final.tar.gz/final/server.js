var http = require('http');
var fs = require('fs');
var url = require('url');
var xhr2proxy = require('xhr2proxy');

http.createServer( function (req, res) {
	console.log(req.url);
	var pathname = url.parse(req.url).pathname;
	var requestUrl=pathname.substr(1);
	//List
	if(req.method=="GET"){
		if(requestUrl=="view"){
			console.log("test from server");
		    var list=require('./list.js');
		    list(req,res);
	    }
	//Delete    
	    else if(requestUrl=="delete"){
		console.log('test from server');
		var del=require('./delete.js');
		 del(req,res);
		}
	//Update(list)	
		else if(requestUrl=="update"){
		console.log('test from server');
		var up=require('./update.js');
		 up(req,res);
		}
	//no7t safa7at el static ya ba4mohandsa ===========>>>>>=======>>>>>
		else{
			fs.readFile(pathname.substr(1), function (err, data) {

			if (err) {
			console.log(err);
			res.writeHead(404, {'Content-Type': 'text/html'});
			}else{
			res.writeHead(200, {'Content-Type': 'text/html'});
			res.write(data.toString());
			}
			res.end();
			});
		}
	}	
	//Add
	else if(req.method=="POST"){
		if(requestUrl=="add"){
			console.log('test from server');
			var ad=require('./add.js');
			ad(req,res);
		}
	//update(save)	
		else if(requestUrl=="saveupdate"){
			console.log('test from server');
			var rep=require('./add.js');
			rep(req,res);
		}
	}
//read
else{
	fs.readFile(pathname.substr(1), function (err, data) {

	if (err) {
	console.log(err);
	res.writeHead(404, {'Content-Type': 'text/html'});
	}else{
	res.writeHead(200, {'Content-Type': 'text/html'});
	res.write(data.toString());
	}
	res.end();
	});
}
}).listen(8000);
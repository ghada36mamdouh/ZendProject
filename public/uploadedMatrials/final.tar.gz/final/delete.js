var mysql = require('mysql');
var url = require('url');

var con = mysql.createConnection
  ({
      host     : 'localhost',
      user     : 'zahra',
      password : 'iti',
      database : 'lab1_Node'
  });


module.exports=function deleteData (req, res) {
   var queryParam = url.parse(req.url, true).query;
    console.log(queryParam.id);
    con.query('DELETE from products where id= ?',[queryParam.id] , function(err,res){
    if(err) throw err;
    });
    res.end();
};

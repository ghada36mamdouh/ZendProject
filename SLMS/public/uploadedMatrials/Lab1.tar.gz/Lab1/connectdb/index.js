
exports.connectdb = function (req,res,i,data){
	var mysql = require('mysql');
	var  querystring = require('querystring') ; 
	
	var connection = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: '123',
	database:'Nodejsdb'
	});
//------------------------------------------------------------------
	if(i == "list"){
	   connection.query("SELECT * from products" , function(err, rows, fields) {
				if (err){
					res.writeHead(404, { 'Content-Type': 'text/plain' });
   					res.end("database error");
				}
				var data = {"data":rows};
				//console.log(JSON.stringify(data));
				res.writeHead(200, { 'Content-Type': 'text/plain'});
                                res.end(JSON.stringify(data));			
		});
	}
//------------------------------------------------------------------
	if(i == "insert"){
	   connection.query('INSERT INTO products SET ?', data , function(err) {
				if (err){
					res.writeHead(404, { 'Content-Type': 'text/plain' });
   					res.end("not");
				}else{
					console.log('inserted good');
                                        res.writeHead(302, {'Location': '/list.html'});
					res.end();
		                        //res.end('inserted');                                       
                                   }			
		});
	}
//------------------------------------------------------------------
	if(i == "delete"){
           console.log("delete from products where id ="+data ) ;
	   connection.query("delete from products where id ="+data , function(err) {
				if (err){
					res.writeHead(404, { 'Content-Type': 'text/plain' });
   					res.end("");
				}
				console.log("del done");
                                res.writeHead(302, {'Location': '/list.html'});
				res.end();
                                //res.end('del done');			
		});
	}
//------------------------------------------------------------------
	if(i == "update"){
	   connection.query("update into products  set where id=  " , function(err, rows, fields) {
				if (err){
					res.writeHead(404, { 'Content-Type': 'text/plain' });
   					res.end("");
				}
				console.log(JSON.stringify(rows));
                                res.end(JSON.stringify(rows));			
		});
	}
	
//------------------------------------------------------------------   
	connection.end();
}



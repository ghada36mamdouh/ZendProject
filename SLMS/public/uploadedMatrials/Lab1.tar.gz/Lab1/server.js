
var http = require('http');
var fs = require('fs');
var path = require('path');
var url = require('url');
var con = require("./connectdb");
var querystring = require('querystring'); // this for posted data

http.createServer(function(req, res) {

    var requestUrl = url.parse(req.url).pathname;
    console.log('requestUrl' +  requestUrl);
    var filePath = '.' + requestUrl; 

     if(filePath == './products'){
                if(req.method == 'GET'){
			 console.log(req.method);
			 con.connectdb(req,res,'list','') ;
		}else if(req.method == 'POST'){
			 console.log(req.method);
			 var body = '';
			 req.on("data", function(chunk) {
				body+=chunk;
			 });
			 req.on("end", function() {
			      	console.log(body);
				var Body = querystring.parse(body);
				console.log(Body);
				con.connectdb(req,res,'insert',Body) ;			 
			    });
		}
/*
                else if(req.method == 'PUT'){
			 console.log(req.method);
                        // con.connectdb(req,res,'update') ;//-------------still
*/
		//con.connectdb(req,res,'list');
   }
   else if(filePath == './del'){
              console.log('del');
              var queryParam = url.parse(req.url, true).query;
              console.log(queryParam.id);
              con.connectdb(req,res,'delete',queryParam.id) ;
   }
   else if(filePath == './edit'){
              console.log('edit');
              var id = url.parse(req.url, true).query.id;
              console.log(id);
              con.connectdb(req,res,'update',id) ;
   }
   else{
		if (filePath == './'){
                filePath = './list.html';
                }
	    var extname = path.extname(filePath);
	    var contentType = 'text/html';
	    switch (extname) {
		case '.js':
		    contentType = 'text/javascript';
		    break;
		case '.css':
		    contentType = 'text/css';
		    break;
		case '.json':
		    contentType = 'application/json';
		    break;
		case '.png':
		    contentType = 'image/png';
		    break;
		case '.jpg':
		    contentType = 'image/jpg';
		    break;
	    }
	    fs.readFile(filePath, function(error, content) {
		if (error) {
		    res.writeHead(404);
		    res.end('Sorry, check with the site admin for error: ' + error.code + ' ..\n');
		} else {
		    res.writeHead(200, { 'Content-Type': contentType });
		    res.end(content, 'utf-8');
		}
	    });
     }//else

}).listen(8000);

console.log('Server running at http://127.0.0.1:8000/');
